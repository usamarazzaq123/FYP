<template>
  <div v-if="user">
    <sidebarVue/>
    <div class="flex flex-col md:pl-64">
      <TopHeader/>
      <main>
        <router-view/>
      </main>
    </div>
  </div>
  <div v-else>
    <router-view/>
  </div>
</template>
<script>
import SidebarVue from '@/components/Sidebar.vue';
import TopHeader from '@/components/TopHeader.vue';

export default {
  name: "App",
  components: {
    SidebarVue,
    TopHeader,
},
  data() {
    return {};
  },
  methods:{
   
  },
  computed: {
    user() {
      return this.$store.state.userData
    }
  }
};
</script>

<style></style>
