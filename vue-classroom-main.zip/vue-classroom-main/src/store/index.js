import { createStore } from 'vuex'

export default createStore({
  state: {
    userIsAuthorized: null,
    userData:null,
    alert:false,
  },
  getters: {
  },
  mutations: {
    setUserIsAuthenticated(state, data) {
      state.userIsAuthorized = data;
    },
    setUserData(state, data) {
      state.userData = data;
    },
    setAlertValue(state, data) {
      state.alert = data;
    },
    
  },
  actions: {

  },
  modules: {
  }
})
