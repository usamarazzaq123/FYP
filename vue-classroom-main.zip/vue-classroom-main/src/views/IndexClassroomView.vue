<template>
  <div class="flex-1 py-6">
    <div class="px-4 sm:px-6 lg:px-8">
      <div v-if="this.$store.state.alert == true">
        <Alert />
      </div>
      <div class="sm:flex sm:items-center pt-3">
        <div class="sm:flex-auto">
          <h1 class="text-3xl font-semibold text-gray-900">Classrooms</h1>
        </div>
        <div
          v-if="$store.state.userData.role == 'student'"
          class="mt-4 sm:mt-0 sm:ml-16 sm:flex-none"
          @click="leaveClass"
        >
          <button
            type="button"
            class="
              inline-flex
              items-center
              justify-center
              rounded-md
              border border-transparent
              bg-red-600
              px-4
              py-2
              text-sm
              font-medium
              text-white
              shadow-sm
              hover:bg-red-700
              focus:outline-none
              focus:ring-2
              focus:ring-red-500
              focus:ring-offset-2
              sm:w-auto
            "
          >
            Leave Classroom
          </button>
        </div>
        <div
          v-if="
            $store.state.userData.role == 'admin' ||
            $store.state.userData.role == 'teacher'
          "
          class="mt-4 sm:mt-0 sm:ml-16 sm:flex-none"
          @click="this.$router.push('/classroom/create')"
        >
          <button
            type="button"
            class="
              inline-flex
              items-center
              justify-center
              rounded-md
              border border-transparent
              bg-indigo-600
              px-4
              py-2
              text-sm
              font-medium
              text-white
              shadow-sm
              hover:bg-indigo-700
              focus:outline-none
              focus:ring-2
              focus:ring-indigo-500
              focus:ring-offset-2
              sm:w-auto
            "
          >
            Create Classroom
          </button>
        </div>
        <div
          v-if="
            $store.state.userData.role == 'admin' ||
            $store.state.userData.role == 'teacher'
          "
          class="mt-4 sm:mt-0 sm:ml-3 sm:flex-none"
        >
          <button v-if="rowSelected"
            @click="edit"
            type="button"
            class="
              inline-flex
              items-center
              justify-center
              rounded-md
              border border-transparent
              bg-yellow-500
              px-4
              py-2
              text-sm
              font-medium
              text-white
              shadow-sm
              hover:bg-yellow-600
              focus:outline-none
              focus:ring-2
              focus:ring-yellow-500
              focus:ring-offset-2
              sm:w-auto
            "
          >
            Edit Classroom
          </button>
        </div>
        <div
          v-if="
            $store.state.userData.role == 'admin' ||
            $store.state.userData.role == 'teacher'
          "
          class="mt-4 sm:mt-0 sm:ml-3 sm:flex-none"
        >
          <button v-if="rowSelected"
            @click="remove"
            type="button"
            class="
              inline-flex
              items-center
              justify-center
              rounded-md
              border border-transparent
              bg-red-500
              px-4
              py-2
              text-sm
              font-medium
              text-white
              shadow-sm
              hover:bg-red-600
              focus:outline-none
              focus:ring-2
              focus:ring-red-500
              focus:ring-offset-2
              sm:w-auto
            "
          >
            Delete Classroom
          </button>
        </div>
      </div>
      <div class="sm:flex-auto pt-4">
        <div class="mt-4">
          <DataTable
            :data="filteredClassData"
            class="display"
            :options="{ select: true }"
            ref="table"
          >
            <thead>
              <tr>
                <th>Id</th>
                <th>Class Name</th>
                <th>Class Code</th>
                <th>Description</th>
              </tr>
            </thead>
          </DataTable>
        </div>
      </div>
    </div>
  </div>
  <!-- </div> -->
</template>
 
 <script>
import DataTable from "datatables.net-vue3";
import DataTablesLib from "datatables.net";
import "datatables.net-select";
DataTable.use(DataTablesLib);
import axios from "axios";
import Alert from "../components/Alert.vue";

export default {
  name: "UserIndexView",
  components: {
    DataTable,
    Alert,
  },
  data() {
    return {
      token: null,
      dt: null,
      rowSelected: null,
      classData: [],
      id: "",
    };
  },
  created() {
    this.token = this.$store.state.userData.token;
    this.index();
  },
  mounted() {
    this.dt = this.$refs.table.dt();
    this.dt.on('select', this.selected);
    this.dt.on('deselect', this.deSelected);
  },
  methods: {
    index() {
      axios
        .get(process.env.VUE_APP_SERVER + "classroom", {
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Bearer ${this.$store.state.userData.token}`,
          },
        })
        .then((response) => {
          console.log(response.data);
          this.classData = response.data;
        })
        .catch((error) => {
          // handle error
          console.log(error);
        });
    },
    edit() {
      let selected = this.dt.rows({ selected: true }).data();
      this.$router.push({
        name: "classroom_edit",
        params: { id: selected[0][0] },
      });
    },
    remove() {
      let selected = this.dt.rows({ selected: true }).data();

      axios
        .delete(process.env.VUE_APP_SERVER + "classroom/" + selected[0][0], {
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Bearer ${this.$store.state.userData.token}`,
          },
        })
        .then((response) => {
          // handle success
          this.index();
          this.$store.commit("setAlertValue", true);
          console.log(response.data);
        })
        .catch((error) => {
          // handle error
          console.log(error);
        });
    },
    leaveClass() {
      let selected = this.dt.rows({ selected: true }).data();
      axios
        .post(
          process.env.VUE_APP_SERVER + "classroom/leave",
          {
            id: JSON.stringify(selected[0][0]),
          },
          {
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
              Authorization: `Bearer ${this.$store.state.userData.token}`,
            },
          }
        )
        .then((response) => {
          // handle success
          this.index();
          this.$store.commit("setAlertValue", true);
          console.log(response.data);
        })
        .catch((error) => {
          // handle error
          console.log(error);
        });
    },
    selected(e, dt, type) {
      if ( type === 'row' ) {
        this.rowSelected = dt.rows({ selected: true }).data()[0];
      }
    },
    deSelected(e, dt, type) {
      if ( type === 'row' ) {
        this.rowSelected = null
      }
    }
  },
  computed: {
    filteredClassData() {
      return this.classData.map((item) => {
        return [item.id, item.name, item.uid, item.description];
      });
    },
  },
};
</script>
 <style>
@import "datatables.net-dt";
.dataTables_wrapper .dataTables_length select {
  width: 60px;
}
table.dataTable {
  width: 100% !important;
  margin: 0px;
}
.dataTables_wrapper .dataTables_paginate .paginate_button.current,
.dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
  background: #4f46e5;
  color: #fff !important;
}
table.dataTable tbody tr {
  background: #f9fafb;
}
table.dataTable tbody tr td {
  height: 30px;
}
table.dataTable tbody tr.selected > * {
  box-shadow: inset 0 0 0 9999px rgb(79, 70, 229);
}
table.dataTable.display > tbody > tr.odd.selected > .sorting_1,
table.dataTable.order-column.stripe > tbody > tr.odd.selected > .sorting_1 {
  box-shadow: inset 0 0 0 9999px rgb(79, 70, 229);
}
table.dataTable.stripe > tbody > tr.odd.selected > *,
table.dataTable.display > tbody > tr.odd.selected > * {
  box-shadow: inset 0 0 0 9999px rgb(79, 70, 229);
}
table.dataTable.display > tbody > tr.even.selected > .sorting_1,
table.dataTable.order-column.stripe > tbody > tr.even.selected > .sorting_1 {
  box-shadow: inset 0 0 0 9999px rgb(79, 70, 229);
}
table.dataTable.hover > tbody > tr.selected:hover > *,
table.dataTable.display > tbody > tr.selected:hover > * {
  box-shadow: inset 0 0 0 9999px rgb(79, 70, 229);
}
</style>