<template>
  <div class="flex-1 py-6">
    <div class="px-4 sm:px-6 lg:px-8">
      <div v-if="this.$store.state.alert === true">
        <Alert />
      </div>
      <div
        v-if="error.status"
        class="
          bg-red-100
          border border-red-400
          text-red-700
          px-4
          py-3
          rounded
          relative
        "
        role="alert"
      >
        <div v-html="error.message"></div>
        <span
          @click="error.status = false"
          class="absolute top-0 bottom-0 right-0 px-4 py-3"
        >
          <svg
            class="fill-current h-6 w-6 text-red-500"
            role="button"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
          >
            <title>Close</title>
            <path
              d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"
            />
          </svg>
        </span>
      </div>
      <div class="sm:flex sm:items-center pt-3">
        <div class="sm:flex-auto">
          <h1 class="text-3xl font-semibold text-gray-900">Lecture's</h1>
        </div>

        <div
          v-if="
            $store.state.userData.role === 'admin' ||
            $store.state.userData.role === 'teacher'
          "
          class="mt-4 sm:mt-0 sm:ml-16 sm:flex-none"
          @click="this.$router.push('/lecture/create')"
        >
          <button
            type="button"
            class="
              inline-flex
              items-center
              justify-center
              rounded-md
              border border-transparent
              bg-indigo-600
              px-4
              py-2
              text-sm
              font-medium
              text-white
              shadow-sm
              hover:bg-indigo-700
              focus:outline-none
              focus:ring-2
              focus:ring-indigo-500
              focus:ring-offset-2
              sm:w-auto
            "
          >
            Add Lecture
          </button>
        </div>
        <div v-if="rowSelected" class="mt-4 sm:mt-0 sm:ml-3 sm:flex-none">
          <button
            @click="showLecture"
            type="button"
            class="
              inline-flex
              items-center
              justify-center
              rounded-md
              border border-transparent
              bg-green-500
              px-4
              py-2
              text-sm
              font-medium
              text-white
              shadow-sm
              hover:bg-green-600
              focus:outline-none
              focus:ring-2
              focus:ring-green-500
              focus:ring-offset-2
              sm:w-auto
            "
          >
            Show Lecture
          </button>
        </div>

        <div
          v-if="
            $store.state.userData.role === 'admin' ||
            $store.state.userData.role === 'teacher'
          "
          class="mt-4 sm:mt-0 sm:ml-3 sm:flex-none"
        >
          <button
            v-if="rowSelected"
            @click="remove"
            type="button"
            class="
              inline-flex
              items-center
              justify-center
              rounded-md
              border border-transparent
              bg-red-500
              px-4
              py-2
              text-sm
              font-medium
              text-white
              shadow-sm
              hover:bg-red-600
              focus:outline-none
              focus:ring-2
              focus:ring-red-500
              focus:ring-offset-2
              sm:w-auto
            "
          >
            Delete Lecture
          </button>
        </div>
      </div>
      <div>
        <div class="pt-8">
          <h2 class="block text-2xl font-medium text-gray-700">
            Select Classroom
          </h2>
          <select
            v-model="classroomId"
            @change="selectClassroom"
            class="
              mt-3
              block
              w-full
              rounded-md
              border-gray-300
              py-2
              pl-3
              pr-10
              text-base
              focus:border-indigo-500 focus:outline-none focus:ring-indigo-500
              sm:text-sm
            "
          >
            <option value="" disabled>Select Classroom</option>
            <option v-for="data in classIds" :key="data.id" :value="data.id">
              {{ data.name }}
            </option>
          </select>
        </div>
      </div>
      <div v-show="show" class="sm:flex-auto pt-4">
        <div class="mt-4">
          <DataTable
            :data="filteredClassData"
            class="display"
            :options="{ select: true }"
            ref="table"
          >
            <thead>
              <tr>
                <th>Id</th>
                <th>Name</th>
              </tr>
            </thead>
          </DataTable>
        </div>
      </div>
    </div>
  </div>
  <!-- </div> -->
</template>
 
 <script>
import DataTable from "datatables.net-vue3";
import DataTablesLib from "datatables.net";
import "datatables.net-select";
DataTable.use(DataTablesLib);
import axios from "axios";
import Alert from "../components/Alert.vue";

export default {
  name: "IndexLectureView",
  components: {
    DataTable,
    Alert,
  },
  data() {
    return {
      token: null,
      dt: null,
      rowSelected: null,
      classData: [],
      classIds: [],
      id: "",
      classroomId: "",
      error: {
        status: false,
        message: "",
      },
    };
  },
  created() {
    this.token = this.$store.state.userData.token;
    this.index();
  },
  mounted() {
    this.dt = this.$refs.table.dt();
    this.dt.on("select", this.selected);
    this.dt.on("deselect", this.deSelected);
  },
  methods: {
    index() {
      axios
        .get(process.env.VUE_APP_SERVER + "classroom", {
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Bearer ${this.$store.state.userData.token}`,
          },
        })
        .then((response) => {
          console.log(response.data);
          this.classIds = response.data;
        })
        .catch((error) => {
          // handle error
          console.log(error);
        });
    },
    selectClassroom() {
      console.log(this.classroomId);
      axios
        .get(
          process.env.VUE_APP_SERVER +
            "classroom/" +
            this.classroomId +
            "/lecture",
          {
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
              Authorization: `Bearer ${this.$store.state.userData.token}`,
            },
          }
        )
        .then((response) => {
          console.log(response.data);
          this.classData = response.data;
        })
        .catch((error) => {
          // handle error
          console.log(error);
        });
      this.show = true;
      // now send a request to api
    },
    showLecture() {
      let selected = this.dt.rows({ selected: true }).data();
      this.$router.push({
        name: "lecture_show",
        params: { id: selected[0][0], classId: this.classroomId },
      });
    },
    remove() {
      let selected = this.dt.rows({ selected: true }).data();

      axios
        .delete(
          process.env.VUE_APP_SERVER +
            "classroom/" +
            this.classroomId +
            "/lecture/" +
            selected[0][0],
          {
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
              Authorization: `Bearer ${this.$store.state.userData.token}`,
            },
          }
        )
        .then((response) => {
          // handle success
          this.$store.commit("setAlertValue", true);
          this.index();
          console.log(response.data);
        })
        .catch((error) => {
          error = error.response.data;
          this.error.message = "";

          if (typeof error.errors !== "undefined") {
            const errors = error.errors;
            Object.keys(errors).forEach((errorKey) => {
              errors[errorKey].forEach((errVal) => {
                this.error.message +=
                  '<p className="block sm">' + errVal + "</p>";
              });
            });
          } else if (typeof error.message !== "undefined") {
            this.error.message =
              '<p className="block sm">' + error.message + "</p>";
          }
          this.error.status = true;
        });
    },
    selected(e, dt, type) {
      if (type === "row") {
        this.rowSelected = dt.rows({ selected: true }).data()[0];
      }
    },
    deSelected(e, dt, type) {
      if (type === "row") {
        this.rowSelected = null;
      }
    },
  },
  computed: {
    filteredClassData() {
      return this.classData.map((item) => {
        return [item.id, item.name];
      });
    },
  },
};
</script>
 <style>
@import "datatables.net-dt";
.dataTables_wrapper .dataTables_length select {
  width: 60px;
}
table.dataTable {
  width: 100% !important;
  margin: 0px;
}
.dataTables_wrapper .dataTables_paginate .paginate_button.current,
.dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
  background: #4f46e5;
  color: #fff !important;
}
table.dataTable tbody tr {
  background: #f9fafb;
}
table.dataTable tbody tr td {
  height: 30px;
}
table.dataTable tbody tr.selected > * {
  box-shadow: inset 0 0 0 9999px rgb(79, 70, 229);
}
table.dataTable.display > tbody > tr.odd.selected > .sorting_1,
table.dataTable.order-column.stripe > tbody > tr.odd.selected > .sorting_1 {
  box-shadow: inset 0 0 0 9999px rgb(79, 70, 229);
}
table.dataTable.stripe > tbody > tr.odd.selected > *,
table.dataTable.display > tbody > tr.odd.selected > * {
  box-shadow: inset 0 0 0 9999px rgb(79, 70, 229);
}
table.dataTable.display > tbody > tr.even.selected > .sorting_1,
table.dataTable.order-column.stripe > tbody > tr.even.selected > .sorting_1 {
  box-shadow: inset 0 0 0 9999px rgb(79, 70, 229);
}
table.dataTable.hover > tbody > tr.selected:hover > *,
table.dataTable.display > tbody > tr.selected:hover > * {
  box-shadow: inset 0 0 0 9999px rgb(79, 70, 229);
}
</style>