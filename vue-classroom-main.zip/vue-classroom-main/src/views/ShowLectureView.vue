<template>
  <div class="min-h-full">
    <main class="py-6">
      <div class="bg-white px-6">
        <div v-if="this.$store.state.alert == true">
          <Alert />
        </div>
        <div
          v-if="error.status"
          class="
            bg-red-100
            border border-red-400
            text-red-700
            px-4
            py-3
            rounded
            relative
          "
          role="alert"
        >
          <div v-html="error.message"></div>
          <span
            @click="error.status = false"
            class="absolute top-0 bottom-0 right-0 px-4 py-3"
          >
            <svg
              class="fill-current h-6 w-6 text-red-500"
              role="button"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
            >
              <title>Close</title>
              <path
                d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"
              />
            </svg>
          </span>
        </div>
      </div>
      <div
        class="
          mx-auto
          mt-8
          grid grid-cols-1
          gap-6
          sm:px-6
          lg:grid-flow-col-dense lg:grid-cols-3
        "
      >
        <div class="space-y-6 lg:col-span-3 lg:col-start-1">
          <!-- Description list-->
          <section aria-labelledby="applicant-information-title">
            <div class="bg-white shadow sm:rounded-lg">
              <div class="px-4 py-5 sm:px-6">
                <h2
                  id="applicant-information-title"
                  class="text-lg font-medium leading-6 text-gray-900"
                >
                  {{ title }}
                </h2>
              </div>
              <div class="border-t border-gray-200 px-4 py-5 sm:px-6">
                <dl class="grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2">
                  <div class="sm:col-span-2">
                    <dt class="text-sm font-medium text-gray-500">
                      Attachments
                    </dt>
                    <dd class="mt-1 text-sm text-gray-900">
                      <ul
                        role="list"
                        class="
                          divide-y divide-gray-200
                          rounded-md
                          border border-gray-200
                        "
                      >
                        <li
                          class="
                            flex
                            items-center
                            justify-between
                            py-3
                            pl-3
                            pr-4
                            text-sm
                          "
                        >
                          <div class="flex w-0 flex-1 items-center">
                            <svg
                              class="h-5 w-5 flex-shrink-0 text-gray-400"
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 20 20"
                              fill="currentColor"
                              aria-hidden="true"
                            >
                              <path
                                fill-rule="evenodd"
                                d="M15.621 4.379a3 3 0 00-4.242 0l-7 7a3 3 0 004.241 4.243h.001l.497-.5a.75.75 0 011.064 1.057l-.498.501-.002.002a4.5 4.5 0 01-6.364-6.364l7-7a4.5 4.5 0 016.368 6.36l-3.455 3.553A2.625 2.625 0 119.52 9.52l3.45-3.451a.75.75 0 111.061 1.06l-3.45 3.451a1.125 1.125 0 001.587 1.595l3.454-3.553a3 3 0 000-4.242z"
                                clip-rule="evenodd"
                              />
                            </svg>
                            <span class="ml-2 w-0 flex-1 truncate">
                              {{ document.name }}</span
                            >
                          </div>
                          <div class="ml-4 flex-shrink-0">
                            <a
                              download
                              :href="document.url"
                              target="_blank"
                              class="
                                font-medium
                                text-indigo-700
                                hover:text-indigo-500
                              "
                              >View Document</a
                            >
                          </div>
                        </li>
                      </ul>
                    </dd>
                  </div>
                </dl>
              </div>
            </div>
          </section>
        </div>
      </div>
    </main>
  </div>
</template>
<script>
import axios from "axios";
import Alert from "../components/Alert.vue";

export default {
  name: "ShowLectureView",
  components: {
    Alert,
  },
  data() {
    return {
      loading: false,
      title: "",
      classroomId: "",
      document: "",
      fileName: "",
      id: "",
      projects: [],
      error: {
        status: false,
        message: "",
      },
    };
  },
  created() {
    this.id = this.$route.params.id;
    this.classroomId = this.$route.params.classId;
    this.index();
  },
  methods: {
    index() {
      axios
        .get(
          process.env.VUE_APP_SERVER +
            "classroom/" +
            this.classroomId +
            "/lecture/" +
            this.id,
          {
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
              Authorization: `Bearer ${this.$store.state.userData.token}`,
            },
          }
        )
        .then((response) => {
          console.log(response.data);
          this.title = response.data.name;
          this.document = response.data.document;
          this.projects = response.data.projects;
        })
        .catch((error) => {
          // handle error
          console.log(error);
        });
    },
  },
};
</script>