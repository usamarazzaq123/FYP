<template>
  <div class="min-h-full">
    <main class="py-6">
      <div class="bg-white px-6">
        <div v-if="this.$store.state.alert == true">
          <Alert />
        </div>
        <div
          v-if="error.status"
          class="
            bg-red-100
            border border-red-400
            text-red-700
            px-4
            py-3
            rounded
            relative
          "
          role="alert"
        >
          <div v-html="error.message"></div>
          <span
            @click="error.status = false"
            class="absolute top-0 bottom-0 right-0 px-4 py-3"
          >
            <svg
              class="fill-current h-6 w-6 text-red-500"
              role="button"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
            >
              <title>Close</title>
              <path
                d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"
              />
            </svg>
          </span>
        </div>
      </div>
      <div
        class="
          mx-auto
          mt-8
          grid grid-cols-1
          gap-6
          sm:px-6
          lg:grid-flow-col-dense lg:grid-cols-3
        "
      >
        <div class="space-y-6 lg:col-span-2 lg:col-start-1">
          <!-- Description list-->
          <section aria-labelledby="applicant-information-title">
            <div class="bg-white shadow sm:rounded-lg">
              <div class="px-4 py-5 sm:px-6">
                <h2
                  id="applicant-information-title"
                  class="text-lg font-medium leading-6 text-gray-900"
                >
                  {{ title }}
                </h2>
              </div>
              <div class="border-t border-gray-200 px-4 py-5 sm:px-6">
                <dl class="grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2">
                  <div class="sm:col-span-2">
                    <dt class="text-sm font-medium text-gray-500">
                      Description
                    </dt>
                    <dd class="mt-1 text-sm text-gray-900">
                      {{ description }}
                    </dd>
                  </div>
                  <div class="sm:col-span-2">
                    <dt class="text-sm font-medium text-gray-500">
                      Attachments
                    </dt>
                    <dd class="mt-1 text-sm text-gray-900">
                      <ul
                        role="list"
                        class="
                          divide-y divide-gray-200
                          rounded-md
                          border border-gray-200
                        "
                      >
                        <li
                          class="
                            flex
                            items-center
                            justify-between
                            py-3
                            pl-3
                            pr-4
                            text-sm
                          "
                        >
                          <div class="flex w-0 flex-1 items-center">
                            <svg
                              class="h-5 w-5 flex-shrink-0 text-gray-400"
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 20 20"
                              fill="currentColor"
                              aria-hidden="true"
                            >
                              <path
                                fill-rule="evenodd"
                                d="M15.621 4.379a3 3 0 00-4.242 0l-7 7a3 3 0 004.241 4.243h.001l.497-.5a.75.75 0 011.064 1.057l-.498.501-.002.002a4.5 4.5 0 01-6.364-6.364l7-7a4.5 4.5 0 016.368 6.36l-3.455 3.553A2.625 2.625 0 119.52 9.52l3.45-3.451a.75.75 0 111.061 1.06l-3.45 3.451a1.125 1.125 0 001.587 1.595l3.454-3.553a3 3 0 000-4.242z"
                                clip-rule="evenodd"
                              />
                            </svg>
                            <span class="ml-2 w-0 flex-1 truncate">
                              {{ document.name }}</span
                            >
                          </div>
                          <div class="ml-4 flex-shrink-0">
                            <a
                              download
                              :href="document.url"
                              target="_blank"
                              class="
                                font-medium
                                text-indigo-700
                                hover:text-indigo-500
                              "
                              >View Document</a
                            >
                          </div>
                        </li>
                      </ul>
                    </dd>
                  </div>
                </dl>
              </div>
            </div>
          </section>
        </div>

        <section
          aria-labelledby="timeline-title"
          class="lg:col-span-1 lg:col-start-3"
        >
          <div class="bg-white px-4 py-5 shadow sm:rounded-lg sm:px-6">
            <h2 id="timeline-title" class="text-lg font-medium text-gray-900">
              Upload Section
            </h2>
            <div class="col-span-3 mt-4">
              <div
                class="
                  mt-1
                  flex
                  justify-center
                  rounded-md
                  border-2 border-dashed border-gray-300
                  px-6
                  pt-5
                  pb-6
                "
              >
                <div class="space-y-1 text-center">
                  <svg
                    class="mx-auto h-12 w-12 text-gray-400"
                    stroke="currentColor"
                    fill="none"
                    viewBox="0 0 48 48"
                    aria-hidden="true"
                  >
                    <path
                      d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </svg>
                  <div class="flex text-sm text-gray-600">
                    <label
                      for="file-upload"
                      class="
                        relative
                        cursor-pointer
                        rounded-md
                        bg-white
                        font-medium
                        text-indigo-600
                        focus-within:outline-none
                        focus-within:ring-2
                        focus-within:ring-indigo-500
                        focus-within:ring-offset-2
                        hover:text-indigo-500
                      "
                    >
                      <span>Upload a file</span>
                      <input
                        @change="processFile($event)"
                        id="file-upload"
                        name="file-upload"
                        type="file"
                        class="sr-only"
                      />
                    </label>
                    <p class="pl-1">or drag and drop</p>
                  </div>
                  <p class="text-xs text-gray-500">pdf, doc up to 10MB</p>
                  <p class="text-xs text-gray-500">{{ upload.name }}</p>
                </div>
              </div>
            </div>
            <div class="justify-stretch mt-6 flex flex-col">
              <button
                @click="uploadDocument"
                type="button"
                class="
                  inline-flex
                  items-center
                  justify-center
                  rounded-md
                  border border-transparent
                  bg-blue-600
                  px-4
                  py-2
                  text-sm
                  font-medium
                  text-white
                  shadow-sm
                  hover:bg-blue-700
                  focus:outline-none
                  focus:ring-2
                  focus:ring-blue-500
                  focus:ring-offset-2
                "
              >
                <button v-if="loading" disabled class="cursor-not-allowed ...">
                  loading ...
                </button>
                <span v-else>Turn In</span>
              </button>
            </div>
          </div>
        </section>
      </div>
      <div>
        <div class="px-4 sm:px-6 lg:px-8 pt-5">
          <div class="sm:flex sm:items-center">
            <div class="sm:flex-auto">
              <h1 class="text-xl font-semibold text-gray-900">
                Uploaded Project
              </h1>
              <p class="mt-2 text-sm text-gray-700">
                A list of Uploaded Projects
              </p>
            </div>
          </div>
          <div class="mt-8 flex flex-col">
            <div class="-my-2 -mx-4 overflow-x-auto sm:-mx-6 lg:-mx-8">
              <div
                class="
                  inline-block
                  min-w-full
                  py-2
                  align-middle
                  md:px-6
                  lg:px-8
                "
              >
                <div
                  class="
                    overflow-hidden
                    shadow
                    ring-1 ring-black ring-opacity-5
                    md:rounded-lg
                  "
                >
                  <table class="min-w-full divide-y divide-gray-300">
                    <thead class="bg-gray-50">
                      <tr>
                        <th
                          scope="col"
                          class="
                            py-3.5
                            pl-4
                            pr-3
                            text-left text-sm
                            font-semibold
                            text-gray-900
                            sm:pl-6
                          "
                        >
                          Student Name
                        </th>
                        <th
                          scope="col"
                          class="
                            px-3
                            py-3.5
                            text-left text-sm
                            font-semibold
                            text-gray-900
                          "
                        >
                          Email
                        </th>
                        <th
                          scope="col"
                          class="
                            px-3
                            py-3.5
                            text-left text-sm
                            font-semibold
                            text-gray-900
                          "
                        >
                          Attachment
                        </th>
                        <th
                          scope="col"
                          class="
                            px-3
                            py-3.5
                            text-left text-sm
                            font-semibold
                            text-gray-900
                          "
                        >
                          Total Marks
                        </th>
                        <th
                          scope="col"
                          class="
                            px-3
                            py-3.5
                            text-left text-sm
                            font-semibold
                            text-gray-900
                          "
                        >
                          Obtain Marks
                        </th>
                      </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 bg-white">
                      <tr
                        v-for="project in projects"
                        :key="project.id"
                      >
                        <td
                          class="
                            whitespace-nowrap
                            py-4
                            pl-4
                            pr-3
                            text-sm
                            font-medium
                            text-gray-900
                            sm:pl-6
                          "
                        >
                          {{ project.user.name }}
                        </td>
                        <td
                          class="
                            whitespace-nowrap
                            px-3
                            py-4
                            text-sm text-gray-500
                          "
                        >
                          {{ project.user.email }}
                        </td>
                        <td
                          class="
                            whitespace-nowrap
                            px-3
                            py-4
                            text-sm text-gray-500
                          "
                        >
                          <a
                            target="_blank"
                            :href="project.document.url"
                            class="underline underline-offset-4 text-indigo-500"
                            >{{ project.document.name }}</a
                          >
                        </td>
                        <td
                          class="
                            whitespace-nowrap
                            py-4
                            pl-4
                            pr-3
                            text-sm
                            font-medium
                            text-gray-900
                            sm:pl-6
                          "
                        >
                          {{ marks }}
                        </td>
                        <td
                          class="
                            whitespace-nowrap
                            px-3
                            py-4
                            text-sm text-gray-500
                          "
                        >
                          <div
                            v-if="
                              $store.state.userData.role === 'student' ||
                              project.marks
                            "
                          >
                            {{
                              project.marks != null
                                ? project.marks
                                : "N/A"
                            }}
                          </div>
                          <div v-else>
                            <input
                              v-model="obtainMarks"
                              class="
                                bg-gray-200
                                appearance-none
                                border-2 border-gray-200
                                rounded
                                w-40
                                mr-3
                                py-2
                                px-4
                                text-gray-700
                                leading-tight
                                focus:outline-none
                                focus:bg-white
                                focus:border-purple-500
                              "
                              placeholder="Enter Marks"
                              type="number"
                            />
                            <button
                              @click="submitMarks(project)"
                              class="
                                bg-indigo-500
                                hover:bg-indigo-600
                                text-white
                                font-bold
                                py-2
                                px-4
                                rounded
                                focus:outline-none focus:shadow-outline
                              "
                              type="button"
                            >
                              <button
                                v-if="loading"
                                type="button"
                                disabled
                                class="cursor-not-allowed ..."
                              >
                                Loading
                              </button>
                              <span v-else>Mark</span>
                            </button>
                          </div>
                        </td>
                      </tr>

                      <!-- More people... -->
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>
<script>
import axios from "axios";
import Alert from "../components/Alert.vue";

export default {
  name: "ShowProjectView",
  components: {
    Alert,
  },
  data() {
    return {
      loading: false,
      title: "",
      description: "",
      classroomId: "",
      marks: "",
      document: "",
      fileName: "",
      upload: "",
      id: "",
      obtainMarks: "",
      projects: [],
      error: {
        status: false,
        message: "",
      },
    };
  },
  created() {
    this.id = this.$route.params.id;
    this.classroomId = this.$route.params.classId;
    this.index();
  },
  methods: {
    index() {
      axios
        .get(
          process.env.VUE_APP_SERVER +
            "classroom/" +
            this.classroomId +
            "/project/" +
            this.id,
          {
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
              Authorization: `Bearer ${this.$store.state.userData.token}`,
            },
          }
        )
        .then((response) => {
          console.log(response.data);
          this.title = response.data.name;
          this.marks = response.data.marks;
          this.description = response.data.description;
          this.document = response.data.document;
          this.projects = response.data.projects;
        })
        .catch((error) => {
          // handle error
          console.log(error);
        });
    },
    processFile(event) {
      this.upload = event.target.files[0];
    },
    uploadDocument() {
      this.loading = true;
      axios
        .post(
          process.env.VUE_APP_SERVER + "project/" + this.id + "/submit",
          {
            document: this.upload,
          },
          {
            headers: {
              "Content-Type": "multipart/form-data",
              Accept: "application/json",
              Authorization: `Bearer ${this.$store.state.userData.token}`,
            },
          }
        )
        .then((response) => {
          console.log(response);
          this.$store.commit("setAlertValue", true);
          this.loading = false;
          this.index();
        })
        .catch((error) => {
          error = error.response.data;
          this.error.message = "";

          if (typeof error.errors !== "undefined") {
            const errors = error.errors;
            Object.keys(errors).forEach((errorKey) => {
              errors[errorKey].forEach((errVal) => {
                this.error.message +=
                  '<p className="block sm">' + errVal + "</p>";
              });
            });
          } else if (typeof error.message !== "undefined") {
            this.error.message =
              '<p className="block sm">' + error.message + "</p>";
          }

          this.error.status = true;
          this.loading = false;
          console.log(error);
        });
    },
    submitMarks(project) {
      if (this.loading) {
        return;
      }
      this.loading = true;
      axios
        .post(
          process.env.VUE_APP_SERVER + "project/" + this.id + "/mark",
          {
            id: project.id,
            marks: this.obtainMarks,
          },
          {
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
              Authorization: `Bearer ${this.$store.state.userData.token}`,
            },
          }
        )
        .then((response) => {
          console.log(response.data);
          this.loading = false;
          this.index();
        })
        .catch((error) => {
          error = error.response.data;
          this.error.message = "";

          if (typeof error.errors !== "undefined") {
            const errors = error.errors;
            Object.keys(errors).forEach((errorKey) => {
              errors[errorKey].forEach((errVal) => {
                this.error.message +=
                  '<p className="block sm">' + errVal + "</p>";
              });
            });
          } else if (typeof error.message !== "undefined") {
            this.error.message =
              '<p className="block sm">' + error.message + "</p>";
          }

          this.error.status = true;
          this.loading = false;
        });
    },
  },
};
</script>

<style></style>